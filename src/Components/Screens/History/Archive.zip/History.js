/* eslint-disable react-native/no-inline-styles */
import {View, Text, Image} from 'react-native';
import React, {useState, useEffect} from 'react';
import {styles} from './HistoryStyle';
import {Wrap, BasicButton, TabIcon, MainStatusBar} from '../../common';
import LinearGradient from 'react-native-linear-gradient';
import {SimpleHeader} from '../../common/SimpleHeader';
import {Actions} from 'react-native-router-flux';
import {BasicInputBox} from '../../common/BasicInputBox';
import {Images, Colors} from '../../../theme/index';
import {getTransactionList} from '../../../Redux/Actions';
import {
  FlatList,
  TextInput,
  TouchableOpacity,
} from 'react-native-gesture-handler';
import {ButtonPrimary} from '../../common/ButtonPrimary';
import fonts from '../../../theme/Fonts';
import * as constants from '../../../Constant';
import Singleton from '../../../Singleton';
import {connect, useDispatch, useSelector} from 'react-redux';
import Loader from '../Loader/Loader';
import {LanguageManager, ThemeManager} from '../../../../ThemeManager';

const History = props => {
  const dispatch = useDispatch();
  const [selectedPage, setselectedPage] = useState(0);
  const [LoadList, setLoadList] = useState(false);
  const [Page, setpage] = useState(1);
  const [limit, setlimit] = useState(25);
  const [isLoading, setisLoading] = useState(false);
  const [selectedCoinData, setselectedCoinData] = useState('');
  const [trx_page, settrx_page] = useState(1);
  const [trx_limit, settrx_limit] = useState(25);
  const [transaction_List, settransaction_List] = useState([]);
  const [totalRecords, setTotalRecordd] = useState('');
  const walletData = useSelector(state => state?.walletReducer);
  // console.log('WallletData---------', walletData);

  useEffect(() => {
    Singleton.getInstance()
      .getData(constants.addresKeyList)
      .then(addrssList => {
        Singleton.getInstance()
          .getData(constants.coinFamilyKeys)
          .then(coinFamilyKeys => {
            console.log(
              'addrssList',
              addrssList,
              'coinFamilyKeys',
              coinFamilyKeys,
            );
            let data = {
              addrsListKeys: JSON.parse(addrssList),
              page: 1,
              limit: trx_limit,
              coin_family: JSON.parse(coinFamilyKeys),
              status: '',
              coin_type: '',
              trnx_type: '',
              from_date: '',
              to_date: '',
            };
            getTransactions(data);
          });
      });
  }, []);

  const getTransactions = data => {
    let access_token = Singleton.getInstance().access_token;
    setisLoading(true),
      setTimeout(() => {
        dispatch(getTransactionList({data, access_token}))
          .then(response => {
            console.log('response===History====', response);
            settransaction_List(response?.data);
            setTotalRecordd(response.meta.total);
            setLoadList(true);
            setisLoading(false);
          })
          .catch(error => {
            console.log('error===History====', error);
            setisLoading(false);
          });
      }, 500);
  };

  const isCloseToBottom = async ({
    layoutMeasurement,
    contentOffset,
    contentSize,
  }) => {
    const paddingToBottom = 60;
    let bottomReached =
      layoutMeasurement.height + contentOffset.y >=
      contentSize.height - paddingToBottom;
    if (bottomReached && LoadList) {
      let page = Page + 1;
      setpage(page);
      setLoadList(false);
      if (transaction_List.length != totalRecords) {
        setisLoading(true);
        let access_token = Singleton.getInstance().access_token;
        Singleton.getInstance()
          .getData(constants.addresKeyList)
          .then(addresKeyList => {
            Singleton.getInstance()
              .getData(constants.coinFamilyKeys)
              .then(coinFamilyKey => {
                let addrsListKeys = JSON.parse(addresKeyList);
                let coinFamilyKeys = JSON.parse(coinFamilyKey);
                let data = {
                  addrsListKeys: addrsListKeys,
                  page: page,
                  limit: trx_limit,
                  coin_family: coinFamilyKeys,
                  status: '',
                  coin_type: '',
                  trnx_type: '',
                  from_date: '',
                  to_date: '',
                };
                dispatch(getTransactionList({data, access_token}))
                  .then(response => {
                    console.log('response===History====close', response);
                    const txnList = transaction_List.concat(response?.data);
                    settransaction_List(txnList);
                    setLoadList(true);
                    setisLoading(false);
                  })
                  .catch(error => {
                    console.log('error===History====', error);
                    setisLoading(false);
                    Singleton.showAlert(err.message);
                  });
              });
          });
      }
    }
  };

  return (
    <Wrap style={{backgroundColor: ThemeManager.colors.backgroundColor}}>
      <MainStatusBar
        backgroundColor={ThemeManager.colors.backgroundColor}
        barStyle={
          ThemeManager.colors.themeColor === 'light'
            ? 'dark-content'
            : 'light-content'
        }
      />
      <SimpleHeader
        title={LanguageManager.History}
        // rightImage={[styles.rightImgStyle]}
        backImage={ThemeManager.ImageIcons.iconBack}
        titleStyle
        imageShow
        back={false}
        backPressed={() => {
          // props.navigation.state.params.onGoBack();
          props.navigation.goBack();
          console.log('back0-0-0>>', Actions.currentScene);
        }}
      />
      <View
        style={{
          height: 2,
          width: '100%',
          backgroundColor: ThemeManager.colors.chooseBorder,
          marginTop: 10,
          opacity: 0.6,
        }}
      />
      {transaction_List.length > 0 ? (
        <FlatList
          bounces={false}
          data={transaction_List}
          keyExtractor={(item, index) => index + ''}
          onScroll={({nativeEvent}) => {
            isCloseToBottom(nativeEvent);
          }}
          renderItem={({item}) => (
            <View style={{flex: 1}}>
              <TouchableOpacity
                onPress={() => {
                  Actions.currentScene != 'TransactionDetail' &&
                    Actions.TransactionDetail({TxnData: item});
                }}>
                <View
                  style={[
                    styles.tokenItem,
                    {backgroundColor: ThemeManager.colors.headerBg},
                  ]}>
                  <View style={styles.viewStyle}>
                    <Image
                      source={Images.sendArrow}
                      style={{
                        height: 18,
                        width: 20,
                        alignSelf: 'center',
                        transform: [
                          {rotate: item.type == 'deposit' ? '90deg' : '-90deg'},
                        ],
                        resizeMode: 'contain',
                        tintColor: ThemeManager.colors.textColor,
                      }}
                    />
                    <View style={{flex: 1, paddingHorizontal: 20}}>
                      <Text
                        style={{
                          // color: Colors.white,
                          color: ThemeManager.colors.textColor,
                          fontSize: 16,
                          fontFamily: fonts.regular,
                        }}>
                        {item.is_smart
                          ? 'Smart Contract Interaction'
                          : item.type == 'deposit'
                          ? 'Received'
                          : 'Sent'}
                      </Text>
                      <Text
                        style={{
                          color: Colors.darkFade,
                          marginTop: 5,
                          fontSize: 14,
                          fontFamily: fonts.regular,
                        }}>
                        {item.from_adrs}
                      </Text>
                    </View>
                    <View
                      style={{alignItems: 'center', justifyContent: 'center'}}>
                      <Text
                        style={{
                          // color: Colors.white,
                          color: ThemeManager.colors.textColor,
                          fontSize: 13,
                          fontFamily: fonts.regular,
                        }}>
                        {item.amount
                          ? Singleton.getInstance().toFixed(item.amount, 8) +
                            ' ' +
                            item.coin_symbol.toUpperCase()
                          : '0.00' + ' ' + item.coin_symbol.toUpperCase()}
                      </Text>
                    </View>
                  </View>
                </View>
              </TouchableOpacity>
            </View>
          )}
        />
      ) : (
        <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
          <Text style={{color: Colors.fadeDot}}>
            {LanguageManager.NoHistory}
          </Text>
        </View>
      )}
      {isLoading && <Loader />}
    </Wrap>
  );
};
// History.navigationOptions = ({navigation}) => {
//   return {
//     header: null,
//     tabBarLabel: ' ',
//     tabBarIcon: ({focused}) => (
//       <TabIcon
//         focused={focused}
//         title={LanguageManager.history}
//         ImgSize={{width: 19, height: 19}}
//         activeImg={Images.HistoryActive}
//         defaultImg={Images.HistoryInActive}
//       />
//     ),
//     tabBarOptions: {
//       style: {
//         backgroundColor: ThemeManager.colors.backgroundColor,
//         // bottom: 5,
//       },
//     },
//   };
// };
export default History;

import React, { useState, useEffect, createRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  TextInput,
  Dimensions,
  BackHandler,
} from 'react-native';
import Clipboard from '@react-native-community/clipboard';
import { Wrap } from '../../common/Wrap';
import { SimpleHeader, SubHeader } from '../../common';
import { Actions } from 'react-native-router-flux';
import colors from '../../../theme/Colors';
import { DotPagination } from '../../common/DotPagination';
import { FlatList } from 'react-native-gesture-handler';
import { styles } from './RecoveryPhraseStyle';
import { Multibtn } from '../../common/Multibtn';
import { Fonts } from '../../../theme';
import { connect, useSelector } from 'react-redux';
import Toast, { DURATION } from 'react-native-easy-toast';
import * as Constants from '../../../Constant';
import Singleton from '../../../Singleton';
import { LanguageManager, ThemeManager } from '../../../../ThemeManager';

const RecoveryPhrase = props => {
  const [copiedText, setCopiedText] = useState(['']);
  const [mnemonicArr, setMnemonicArray] = useState(['']);
  const [mnemonics, setMnemonics] = useState(['']);
  //   const mnemonics = useSelector(state => state?.createWalletReducer?.walletData?.mnemonics)
  const toastRef = createRef();
  const [PrvtKey, setPrvtKey] = useState('');
  const [IsPrvtKey, setIsPrvtKey] = useState(false);

  useEffect(() => {
    let backHandle = null;
    backHandle = BackHandler.addEventListener('hardwareBackPress', backAction);
    props.navigation.addListener('didFocus', () => {
      backHandle = BackHandler.addEventListener(
        'hardwareBackPress',
        backAction,
      );
    });
    props.navigation.addListener('didBlur', () => {
      backHandle?.remove();
    });
  }, [props]);

  const backAction = () => {
    //Actions.jump('BackupOptions');
    props.screenType == "Editwallet" ? Actions.jump('EditWallet') : Actions.jump('BackupOptions')
    return true;
  };
  useEffect(() => {
    if (props.screenType == "Editwallet") {
      console.log(">>>>>>walletItem", props.walletItem);
      if (props.walletItem.privateKey == undefined) {
        let mnemonics = props.walletItem.mnemonics
        setIsPrvtKey(false);
        setMnemonics(mnemonics);
        let mnemonicArr = mnemonics ? mnemonics.split(' ') : [];
        setMnemonicArray(mnemonicArr);
      } else {
        setPrvtKey(props.walletItem.privateKey);
        setIsPrvtKey(true);
      }
      // let mnemonics = await Singleton.getInstance().getData( response.defaultEthAddress,);
      //   if (mnemonics == null) {
      //     Singleton.getInstance()
      //       .getData(`${Singleton.getInstance().defaultEthAddress}_pk`)
      //       .then(ethPvtKey => {
      //         console.log('ethPvtKey--------', ethPvtKey);
      //         setPrvtKey(ethPvtKey);
      //         setIsPrvtKey(true);
      //         // alert(ethPvtKey)
      //       });
      //   } else {
      //     setIsPrvtKey(false);
      //     setMnemonics(mnemonics);
      //     let mnemonicArr = mnemonics ? mnemonics.split(' ') : [];
      //     setMnemonicArray(mnemonicArr);
      //   }

    } else {
      Singleton.getInstance()
        .getData(Constants.login_data)
        .then(async res => {
          let response = JSON.parse(res);
          let mnemonics = await Singleton.getInstance().getData(response.defaultEthAddress,);
          if (mnemonics == null) {
            Singleton.getInstance()
              .getData(`${Singleton.getInstance().defaultEthAddress}_pk`)
              .then(ethPvtKey => {
                console.log('ethPvtKey--------', ethPvtKey);
                setPrvtKey(ethPvtKey);
                setIsPrvtKey(true);
                // alert(ethPvtKey)
              });
          } else {
            setIsPrvtKey(false);
            setMnemonics(mnemonics);
            let mnemonicArr = mnemonics ? mnemonics.split(' ') : [];
            setMnemonicArray(mnemonicArr);
          }
        })
        .catch(error => { });
    }

  }, []);

  return (
    <Wrap style={{ backgroundColor: ThemeManager.colors.backgroundColor }}>
      <View style={styles.mainView}>
        {/* <SubHeader
          title="Recovery"
          Subtitle="Phrase"
          headerstyle={{
            marginTop: Dimensions.get('screen').height < 670 ? 8 : 40,
          }}
        /> */}
        <SimpleHeader
          title={LanguageManager.recoveryPhrase}
          // rightImage={[styles.rightImgStyle]}
          backImage={ThemeManager.ImageIcons.iconBack}
          titleStyle
          imageShow
          back={false}
          backPressed={() => {
            // props.navigation.state.params.onGoBack();
            // props.navigation.goBack();
            //Actions.jump('BackupOptions');
            props.screenType == "Editwallet" ? Actions.jump('EditWallet') : Actions.jump('BackupOptions')
          }}
        />
        <View
          style={{
            height: 2,
            width: '100%',
            backgroundColor: ThemeManager.colors.chooseBorder,
            marginTop: 10,
            opacity: 0.6,
          }}
        />
        <View style={styles.textView}>
          <Text style={styles.text}>{LanguageManager.recoveryPhraseText}</Text>
          {/* <Text style={{ color: colors.fadetext }}>
            somewhere safe, if you lose this phrase you{' '}
          </Text>
          <Text style={{ color: colors.fadetext }}>
            may not be able to access your wallet.
          </Text> */}
        </View>

        <View style={{ marginTop: 20 }}>
          {console.log('PrvtKey  >>', PrvtKey)}
          {!IsPrvtKey ? (
            <FlatList
              data={mnemonicArr}
              numColumns={2}
              contentContainerStyle={styles.contentContainer}
              keyExtractor={(item, index) => index + ' '}
              renderItem={({ item, index }) => (
                <View style={styles.listView}>
                  <View style={styles.listContainer}>
                    <Text
                      style={[
                        styles.listText,
                        { color: ThemeManager.colors.textColor },
                      ]}>
                      {index + 1 + '.  ' + item}
                    </Text>
                  </View>
                </View>
              )}
            />
          ) : (
            <View style={styles.listContainersingle}>
              <Text style={[
                styles.listText,
                { color: ThemeManager.colors.textColor },
              ]}>{PrvtKey}</Text>
            </View>
          )}

          <TouchableOpacity
            onPress={() => {
              Clipboard.setString(!IsPrvtKey ? mnemonics : PrvtKey);
              toastRef.current.show(Constants.COPIED);
            }}
            style={styles.copyBtn}>
            <Text
              style={[
                styles.heading,
                { color: 'black', fontFamily: Fonts.regular },
              ]}>
              {LanguageManager.copyPhrase}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      <Multibtn
        style={{ bottom: 50 }}
        firstBtn={() => { props.screenType == "Editwallet" ? Actions.jump('EditWallet') : Actions.jump('BackupOptions') }}
        secondBtn={() => Actions.VerifyPhrase()}
        firsttext={LanguageManager.Back}
        firstTextStyle={{ color: ThemeManager.colors.textColor }}
        secondtext=""
        borderColor={ThemeManager.colors.textColor}
      />
      {/* <DotPagination style={{ marginTop: 20 }} activeDotNumber={3} /> */}
      <Toast ref={toastRef} />
    </Wrap>
  );
};

export default RecoveryPhrase;

import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  Dimensions,
  BackHandler,
  ScrollView,
} from 'react-native';
import {Actions} from 'react-native-router-flux';
import colors from '../../../theme/Colors';
import {MainStatusBar, SubHeader} from '../../common';
import SmoothPinCodeInput from 'react-native-smooth-pincode-input';
import {Wrap} from '../../common/Wrap';
import {ButtonPrimary} from '../../common/ButtonPrimary';
import {styles} from './CreatePINStyle';
import Singleton from '../../../Singleton';
import * as constants from './../../../Constant';
import {LanguageManager, ThemeManager} from '../../../../ThemeManager';
import {getInfuraLink} from '../../../Redux/Actions';
import {connect, useDispatch, useSelector} from 'react-redux';
import HeaderwithBackIcon from '../../common/HeaderWithBackIcon';
let length = 0;
const CreatePIN = props => {
  const [pin, setPin] = useState('');
  const dispatch = useDispatch();
  const [confirmPin, setconfirmPin] = useState('');

  useEffect(() => {
    getInfuraMainLink();
    const backAction = () => {
      console.log('i CreatePIN');
      Actions.pop();
      return true;
    };

    const backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      backAction,
    );

    return () => backHandler.remove();
  }, []);

  const getInfuraMainLink = () => {
    dispatch(getInfuraLink())
      .then(response => {
        // console.log('response==getInfuraMainLink==== create', response);
        constants.mainnetInfuraLink = response.link;
      })
      .catch(error => {
        console.log('error==getInfuraMainLink=== create', error);
      });
  };
  const onProceed = () => {
    if (pin.length == 0 || pin.length < 6) {
      Singleton.showAlert(constants.ENTERPIN);
      return;
    }
    if (confirmPin.length == 0 || confirmPin.length < 6) {
      Singleton.showAlert(constants.CONFIRMPIN);
      return;
    }
    if (pin != confirmPin) {
      Singleton.showAlert(constants.CHECKPIN);
      return;
    } else {
      if (props.redirectTo) {
        Singleton.getInstance().saveData(constants.ENABLE_PIN, 'true');
        Singleton.getInstance().saveData(constants.PIN, pin);
        Actions.currentScene != 'Security' && Actions.jump('Security');
      } else {
        Singleton.getInstance().saveData(constants.PIN, pin);
        Singleton.getInstance().saveData(constants.ENABLE_PIN, 'true');
        Actions.currentScene != 'CreateWallet' && Actions.CreateWallet();
      }
    }
  };
  // console.log('IOS---', Dimensions.get('screen').height);
  return (
    <Wrap style={{backgroundColor: ThemeManager.colors.backgroundColor}}>
      <MainStatusBar
        backgroundColor={ThemeManager.colors.backgroundColor}
        barStyle={
          ThemeManager.colors.themeColor === 'light'
            ? 'dark-content'
            : 'light-content'
        }
      />
      <ScrollView>
        <View style={styles.mainView}>
          {/* <SubHeader
            title={LanguageManager.title1}
            headerTextStyle={{color: ThemeManager.colors.textColor}}
            subTitleStyle={{color: ThemeManager.colors.textColor}}
            Subtitle={LanguageManager.title2}
            headerstyle={{marginTop: 40}}
          /> */}
          {/* <HeaderwithBackIcon iconLeft={ThemeManager.ImageIcons.iconBack} /> */}
          <Text
            style={[
              styles.labelCreatePin,
              {color: ThemeManager.colors.textColor},
            ]}>
            {LanguageManager.CreatePin}
          </Text>
          <View style={styles.textInputView}>
            <View style={styles.textInput}>
              <Text style={styles.pinText}>{LanguageManager.EnterPin}</Text>
            </View>
            <View style={[styles.inputView]}>
              <SmoothPinCodeInput
                autoFocus={true}
                password
                mask="﹡"
                cellSize={42}
                codeLength={6}
                cellStyleFocused={{borderColor: ThemeManager.colors.textColor}}
                cellStyle={[
                  styles.cellStyle,
                  {borderColor: ThemeManager.colors.inputBoxColor},
                ]}
                textStyle={[
                  styles.inputText,
                  {color: ThemeManager.colors.textColor},
                ]}
                value={pin}
                onTextChange={text => {
                  length = text.length;
                  setPin(text);
                }}
              />
            </View>
          </View>
          <View style={styles.confiemPinView}>
            <View style={styles.textInput}>
              <Text style={styles.pinText}>{LanguageManager.ConfirmPin}</Text>
            </View>
            <View style={styles.inputView}>
              <SmoothPinCodeInput
                // autoFocus={length == 6 && true}
                password
                mask="﹡"
                cellSize={42}
                codeLength={6}
                cellStyleFocused={{borderColor: ThemeManager.colors.textColor}}
                cellStyle={[
                  styles.cellStyle,
                  {borderColor: ThemeManager.colors.inputBoxColor},
                ]}
                textStyle={[
                  styles.inputText,
                  {color: ThemeManager.colors.textColor},
                ]}
                value={confirmPin}
                onTextChange={text => setconfirmPin(text)}
              />
            </View>
          </View>
          <ButtonPrimary
            btnstyle={styles.btnStyle}
            onpress={() => onProceed()}
            colors={Singleton.getInstance().dynamicColor}
            text={LanguageManager.proceed}
          />
          {/* <View style={{ paddingVertical: 20 }}>
          <Text style={styles.createPinTxt}>{LanguageManager.CreatingPin}</Text>
        </View> */}
          <View style={styles.pinRequiredTextWrap}>
            <Text style={styles.text}>{LanguageManager.PinReq}</Text>
          </View>
          <TouchableOpacity
            onPress={() => Actions.pop()}
            style={styles.btnView2}>
            <Text style={{color: colors.white}}>{LanguageManager.Back}</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </Wrap>
  );
};

export default CreatePIN;

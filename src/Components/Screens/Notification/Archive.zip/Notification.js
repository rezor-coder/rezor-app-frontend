/* eslint-disable react-native/no-inline-styles */
import React, {Component} from 'react';
import {
  View,
  Image,
  Text,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Clipboard,
  Modal,
  Alert,
  BackHandler,
} from 'react-native';
import styles from './NotificationStyle';
import {Images, Colors, Fonts} from '../../../theme';
import {Actions} from 'react-native-router-flux';
import Singleton from '../../../Singleton';
import * as Constants from '../../../Constant';
import {connect} from 'react-redux';
import moment from 'moment';
import {MainStatusBar, SimpleHeader, TitleHeader, Wrap} from '../../common';
import {getNotificationList} from '../../../Redux/Actions/index';
import Loader from '../Loader/Loader';
import FastImage from 'react-native-fast-image';
import {LanguageManager, ThemeManager} from '../../../../ThemeManager';

class Notification extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isLoading: false,
      page: 1,
      limit: 25,
      loadList: false,
      totalRecords: 0,
      showShimmer: true,
      notificationList: [],
    };
  }
  componentDidMount() {
    this.getNotificationList();
    this.props.navigation.addListener('didFocus', this.screenFocus);
    this.props.navigation.addListener('didBlur', this.screenBlur);
  }
  screenBlur = () => {
    BackHandler.removeEventListener('hardwareBackPress', this.backAction);
  };
  screenFocus = () => {
    BackHandler.addEventListener('hardwareBackPress', this.backAction);
  };
  backAction = () => {
    Actions.pop();
    return true;
  };
  getNotificationList() {
    this.setState({isLoading: true});
    let page = this.state.page;
    let limit = this.state.limit;
    let access_token = Singleton.getInstance().access_token;
    Singleton.getInstance()
      .getData(Constants.addresKeyList)
      .then(addresKeyList => {
        Singleton.getInstance()
          .getData(Constants.coinFamilyKeys)
          .then(coinFamilyKey => {
            let addrsListKeys = JSON.parse(addresKeyList);
            let coinFamilyKeys = JSON.parse(coinFamilyKey);
            this.props
              .getNotificationList({
                page,
                limit,
                addrsListKeys,
                coinFamilyKeys,
                access_token,
              })
              .then(res => {
                this.setState({
                  notificationList: res.data,
                  totalRecords: res.meta.total,
                  loadList: true,
                  isLoading: false,
                });
              })
              .catch(err => {
                this.setState({isLoading: false});
                Singleton.showAlert(err.message);
              });
          })
          .catch(err => {
            this.setState({isLoading: false});
            Singleton.showAlert(err.message);
          });
      });
  }

  isCloseToBottom = async ({layoutMeasurement, contentOffset, contentSize}) => {
    const paddingToBottom = 60;
    let bottomReached =
      layoutMeasurement.height + contentOffset.y >=
      contentSize.height - paddingToBottom;
    if (bottomReached && this.state.loadList) {
      let page = this.state.page + 1;
      this.setState({page: page, loadList: false}, () => {
        if (this.state.notificationList.length != this.state.totalRecords) {
          this.setState({isLoading: true});
          let limit = this.state.limit;
          let access_token = Singleton.getInstance().access_token;
          Singleton.getInstance()
            .getData(Constants.addresKeyList)
            .then(addresKeyList => {
              Singleton.getInstance()
                .getData(Constants.coinFamilyKeys)
                .then(coinFamilyKey => {
                  let addrsListKeys = JSON.parse(addresKeyList);
                  let coinFamilyKeys = JSON.parse(coinFamilyKey);
                  this.props
                    .getNotificationList({
                      page,
                      limit,
                      addrsListKeys,
                      coinFamilyKeys,
                      access_token,
                    })
                    .then(response => {
                      console.log(
                        'response notification list view-- on scroll- ',
                        response,
                      );
                      let new_data = response.data;
                      this.setState({
                        notificationList:
                          this.state.notificationList.concat(new_data),
                        isLoading: false,
                        loadList: true,
                      });
                    })
                    .catch(error => {
                      this.setState({isLoading: false});
                      Singleton.showAlert(error.message);
                    });
                })
                .catch(err => {
                  this.setState({isLoading: false});
                  Singleton.showAlert(err.message);
                });
            });
        }
      });
    }
  };
  render() {
    return (
      <>
        <Wrap style={{backgroundColor: ThemeManager.colors.backgroundColor}}>
          <MainStatusBar
            backgroundColor={ThemeManager.colors.backgroundColor}
            barStyle={
              ThemeManager.colors.themeColor === 'light'
                ? 'dark-content'
                : 'light-content'
            }
          />
          <View
            style={{
              height: 50,
              width: '100%',
              // backgroundColor: 'red',
              position: 'absolute',
              zIndex: 1000,
            }}>
            <SimpleHeader
              title={LanguageManager.Notifications}
              // rightImage={[styles.rightImgStyle]}
              backImage={ThemeManager.ImageIcons.iconBack}
              titleStyle
              imageShow
              back={false}
              backPressed={() => {
                // props.navigation.state.params.onGoBack();
                // this.props.navigation.goBack();
                Actions.currentScene == 'Notification' && Actions.pop();
                // alert('hello');
              }}
            />
          </View>

          <View
            style={{
              height: 2,
              width: '100%',
              backgroundColor: ThemeManager.colors.chooseBorder,
              marginTop: 10,
              opacity: 0.6,
            }}
          />
          <View style={{flex: 1, paddingTop: 25}}>
            {this.state.notificationList.length > 0 ? (
              <FlatList
                bounces={false}
                data={this.state.notificationList}
                showsVerticalScrollIndicator={false}
                onScroll={({nativeEvent}) => {
                  this.isCloseToBottom(nativeEvent);
                }}
                renderItem={({item, index}) => {
                  return (
                    <TouchableOpacity
                      activeOpacity={0.7}
                      onPress={() => {
                        Actions.currentScene != 'TransactionDetail' &&
                          Actions.TransactionDetail({TxnData: item});
                      }}>
                      <View style={styles.tokenItem}>
                        <View style={styles.viewStyle}>
                          <View
                            style={{
                              width: '20%',
                              justifyContent: 'center',
                              alignItems: 'flex-end',
                              paddingRight: 10,
                            }}>
                            {item.type.toUpperCase() == 'DEPOSIT' &&
                            item.state.toUpperCase() != 'FAILED' ? (
                              <FastImage
                                style={styles.imgStyle}
                                resizeMode={'contain'}
                                source={Images.icon_receive_transaction}
                              />
                            ) : item.type.toUpperCase() == 'WITHDRAW' &&
                              item.state.toUpperCase() != 'FAILED' ? (
                              <FastImage
                                style={styles.imgStyle}
                                resizeMode={'contain'}
                                source={Images.icon_sent}
                              />
                            ) : (
                              <FastImage
                                style={styles.imgStyle}
                                resizeMode={'contain'}
                                source={Images.transaction_erro_icon}
                              />
                            )}
                          </View>
                          <View
                            style={{
                              width: '80%',
                              alignContent: 'center',
                              justifyContent: 'center',
                            }}>
                            <Text style={styles.FlatlistCellText}>
                              {item.message}
                            </Text>
                            <Text style={styles.FlatlistCellTextt}>
                              {moment(item.created_at).format(
                                'DD MMM, YYYY | hh:mm a',
                              )}
                            </Text>
                          </View>
                        </View>
                      </View>
                    </TouchableOpacity>
                  );
                }}
                keyExtractor={item => item.id}
              />
            ) : (
              <View style={styles.mainView}>
                <Text
                  style={[
                    styles.textStyle,
                    {color: ThemeManager.colors.textColor},
                  ]}>
                  {LanguageManager.NoNoti}
                </Text>
              </View>
            )}
          </View>
          {this.state.isLoading == true && <Loader />}
        </Wrap>
        <SafeAreaView style={{backgroundColor: Colors.black}} />
      </>
    );
  }
}
const mapStateToProp = state => {
  return {};
};
export default connect(mapStateToProp, {getNotificationList})(Notification);

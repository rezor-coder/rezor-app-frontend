import {StyleSheet} from 'react-native';
import {ThemeManager} from '../../../../ThemeManager';
import {Fonts, Colors} from '../../../theme';

export default StyleSheet.create({
  mainView: {
    justifyContent: 'center',
    color: ThemeManager.colors.textColor,
    flex: 1,
    marginTop: -100,
  },

  textStyle: {
    // color: Colors.white,
    color: ThemeManager.colors.textColor,
    textAlign: 'center',
  },
  imgStyle: {width: 45, height: 45},
  viewStyle: {
    flexDirection: 'row',
    flex: 1,
    // justifyContent: 'space-between'
  },
  headerStyle: {
    paddingTop: 20,
    paddingBottom: 28,
    marginHorizontal: 18,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  titleStyle: {
    fontFamily: Fonts.regular,
    fontSize: 22,
    marginLeft: 13,
    // color: Colors.white,
    color: ThemeManager.colors.textColor,
  },
  texttttStyle: {
    fontFamily: Fonts.regular,
    fontSize: 20,
    alignSelf: 'center',
    // color: Colors.white,
    color: ThemeManager.colors.textColor,
  },

  tokenItem: {
    // borderWidth: 1,
    // borderColor: Colors.lossText,
    paddingVertical: 15,
    paddingHorizontal: 5,
    borderRadius: 10,
    marginVertical: 5,
    marginHorizontal: 15,
    // alignItems: 'stretch',
    backgroundColor: Colors.headerBg,
    // elevation: 5
  },

  FlatlistCellText: {
    fontSize: 16,
    color: Colors.activeText,
    fontFamily: Fonts.regular,
    textAlign: 'left',
  },
  FlatlistCellTextt: {
    fontSize: 12,
    fontFamily: Fonts.regular,
    color: Colors.lightWhite,
    marginTop: 5,
    marginBottom: 2,
  },
});

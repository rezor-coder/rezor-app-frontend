/* eslint-disable react-native/no-inline-styles */
import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  LayoutAnimation,
  Image,
  TouchableOpacity,
  FlatList,
  BackHandler,
} from 'react-native';
import {Wrap} from '../../common/Wrap';
import {
  MainHeader,
  MainStatusBar,
  SearchBar,
  SubHeader,
  TabIcon,
} from '../../common';
import {Actions} from 'react-native-router-flux';
import images from '../../../theme/Images';
import styles from './MarketStyle';
import LinearGradient from 'react-native-linear-gradient';
import {Colors, Fonts, Images} from '../../../theme';
import {useSelector} from 'react-redux';
import {AreaChart, Path} from 'react-native-svg-charts';
import * as shape from 'd3-shape';
import Singleton from '../../../Singleton';
import {BASE_IMAGE} from '../../../Endpoints';
import {useDispatch} from 'react-redux';
import * as constants from '../../../Constant';
import {
  getMyWallets,
  walletDataUpdate,
  getWalletCoinListOrder,
} from '../../../Redux/Actions';
import Loader from '../Loader/Loader';
import {LanguageManager, ThemeManager} from '../../../../ThemeManager';
import {CoustomModal} from '../../common/CoustomModal';
import {EventRegister} from 'react-native-event-listeners';
import * as Constants from '../../../Constant';
import Hot from '../Hot/Hot';
import Gainer from '../Gainer/Gainer';
import Loser from '../Loser/Loser';
import HourChanges from '../HourChanges/HourChanges';
import TradeHeader from '../../common/TradeHeader';

const Line = ({line}) => (
  <Path key={'line'} d={line} stroke={'green'} fill={'none'} />
);
const Line1 = ({line}) => (
  <Path key={'line'} d={line} stroke={'red'} fill={'none'} />
);
let Page = 1;
let Search = '';
let showLoad = true;

const tabData = [
  {title: LanguageManager.Hot},
  {title: LanguageManager.Gainer},
  {title: LanguageManager.Loser},
  {title: LanguageManager.Vol},
];

let selectedInd = 0;

const Market = props => {
  const dispatch = useDispatch();
  const [showLoader, setShowLoader] = useState(true);
  const [openSearch, setopenSearch] = useState(false);
  const [searchSet, setsearchSet] = useState(false);
  const [isLoading, setisLoading] = useState(false);
  const [loadList, setLoadList] = useState(false);
  const [totalRecords, setTotalRecords] = useState('');
  const [coinData, setCoinData] = useState([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [tabstatus, setTabSatus] = useState('Hot');
  const [HotData, setHotData] = useState([]);
  const [GainerData, setGainerData] = useState([]);
  const [LoserData, setLoserData] = useState([]);
  const [HourlyData, setHourlyData] = useState([]);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const {currentTheme} = useSelector(state => state.mnemonicreateReducer);
  const onSearchBarClick = value => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.linear);
    setopenSearch(value);
  };

  // useEffect(() => {
  //   BackHandler.addEventListener("hardwareBackPress", backAction);
  //   return () => {
  //     BackHandler.removeEventListener("hardwareBackPress", backAction);
  //   };
  // }, [backAction]);

  // const backAction = () => {
  //   return true;
  // }
  useEffect(() => {
    selectedInd = 0;
    getWalletData();
    getHot();
    getGainer();
    getLoser();
    getHourly();
    props.navigation.addListener('didFocus', () => {
      // alert(Constants.mainnetInfuraLink)
      Search = '';
      setopenSearch(false);
      getHot();
      getGainer();
      getLoser();
      getHourly();
      getWalletData();
      EventRegister.addEventListener('downModal', data1 => {
        setModalVisible(false);
      });
    });
  }, []);
  const getWalletData = () => {
    Singleton.getInstance()
      .getData(constants.WALLET_LIST)
      .then(wallet_list => {
        // console.log('wallet_listqqqqq', wallet_list);
        if (wallet_list) {
          showLoad = false;
          setCoinData(JSON.parse(wallet_list));
        }
        getMyWalletsData();
      });
  };

  const getHot = () => {
    let data = {
      fiat_type: Singleton.getInstance().CurrencySelected,
      order_type: 'hot',
    };
    let access_token = Singleton.getInstance().access_token;
    dispatch(getWalletCoinListOrder({data, access_token}))
      .then(response => {
        // console.log('response==getCoinListOrder====', response);
        setHotData(response.data);
      })
      .catch(error => {
        console.log('error==getCoinListOrder====', error);
      });
  };
  const getGainer = () => {
    let data = {
      fiat_type: Singleton.getInstance().CurrencySelected,
      order_type: 'gainer',
    };
    let access_token = Singleton.getInstance().access_token;
    dispatch(getWalletCoinListOrder({data, access_token}))
      .then(response => {
        // console.log('response=gainer=getCoinListOrder====', response);
        setGainerData(response.data);
      })
      .catch(error => {
        console.log('error==getCoinListOrder====', error);
      });
  };
  const getLoser = () => {
    let data = {
      fiat_type: Singleton.getInstance().CurrencySelected,
      order_type: 'loser',
    };
    let access_token = Singleton.getInstance().access_token;
    dispatch(getWalletCoinListOrder({data, access_token}))
      .then(response => {
        // console.log('response=loser=getCoinListOrder====', response);
        setLoserData(response.data);
      })
      .catch(error => {
        console.log('error==getCoinListOrder====', error);
      });
  };
  const getHourly = () => {
    let data = {
      fiat_type: Singleton.getInstance().CurrencySelected,
      order_type: '24hVol',
    };
    let access_token = Singleton.getInstance().access_token;
    dispatch(getWalletCoinListOrder({data, access_token}))
      .then(response => {
        console.log('response=hour=getCoinListOrder====', response);
        setHourlyData(response.data);
      })
      .catch(error => {
        console.log('error==getCoinListOrder====', error);
      });
  };

  const onChangeText = text => {
    let coinsData = coinData;
    coinsData = coinData.filter(item => {
      return item.coin_name.includes(text);
    });
    setCoinData(coinsData);
  };

  const getMyWalletsData = () => {
    let page = Page;
    let limit = 25;
    let access_token = Singleton.getInstance().access_token;
    let search = Search;
    Singleton.getInstance()
      .getData(constants.addresKeyList)
      .then(addresKeyList => {
        Singleton.getInstance()
          .getData(constants.coinFamilyKeys)
          .then(coinFamilyKey => {
            let addrsListKeys = JSON.parse(addresKeyList);
            let coinFamilyKeys = JSON.parse(coinFamilyKey);
            showLoad == true ? setisLoading(true) : setisLoading(false);
            dispatch(
              getMyWallets({
                page,
                limit,
                addrsListKeys,
                coinFamilyKeys,
                access_token,
                search,
              }),
            )
              .then(response => {
                // console.log('chk resp:::', response);
                // const data = coinData.concat(response)
                setCoinData(response);
                setisLoading(false);
                setLoadList(true);
                setTotalRecords(response[0]?.totalRecords);
              })
              .catch(error => {
                setisLoading(false);
              });
          });
      });
  };
  const coinSelection = item => {
    console.log('chk item wallet::::', item);
    if (item.coin_family == 1) {
      Actions.currentScene != 'SendETH' && Actions.SendETH({walletData: item});
    } else if (item.coin_family == 6) {
      Actions.currentScene != 'SendBNB' && Actions.SendBNB({walletData: item});
    }
  };
  const isCloseToBottom = async ({
    layoutMeasurement,
    contentOffset,
    contentSize,
  }) => {
    const paddingToBottom = 60;
    let bottomReached =
      layoutMeasurement.height + contentOffset.y >=
      contentSize.height - paddingToBottom;
    console.log('chk is closeToBottom');
    if (bottomReached && loadList) {
      let pagee = Page + 1;
      setLoadList(false);
      if (coinData.length != totalRecords) {
        setisLoading(true);
        let page = pagee;
        let limit = 25;
        let access_token = Singleton.getInstance().access_token;
        let search = Search;
        Singleton.getInstance()
          .getData(constants.addresKeyList)
          .then(addresKeyList => {
            Singleton.getInstance()
              .getData(constants.coinFamilyKeys)
              .then(coinFamilyKey => {
                let addrsListKeys = JSON.parse(addresKeyList);
                let coinFamilyKeys = JSON.parse(coinFamilyKey);
                showLoader == true ? setisLoading(true) : setisLoading(false);
                dispatch(
                  getMyWallets({
                    page,
                    limit,
                    addrsListKeys,
                    coinFamilyKeys,
                    access_token,
                    search,
                  }),
                )
                  .then(response => {
                    // console.log('chk resp:::', response);
                    setCoinData(coinData.concat(response));
                    setisLoading(false);
                  })
                  .catch(error => {
                    setisLoading(false);
                  });
              });
          });
      }
    }
  };
  const getCoinList = () => {
    let page = Page;
    let limit = 25;
    let search = Search;
    let access_token = Singleton.getInstance().access_token;
    setisLoading(true);
    Singleton.getInstance()
      .getData(constants.addresKeyList)
      .then(addresKeyList => {
        Singleton.getInstance()
          .getData(constants.coinFamilyKeys)
          .then(coinFamilyKey => {
            let addrsListKeys = JSON.parse(addresKeyList);
            let coinFamilyKeys = JSON.parse(coinFamilyKey);
            setisLoading(true);
            dispatch(
              getMyWallets({
                page,
                limit,
                addrsListKeys,
                coinFamilyKeys,
                access_token,
                search,
              }),
            )
              .then(response => {
                // console.log('chk resp:::', response);
                setCoinData(response);
                setisLoading(false);
              })
              .catch(error => {
                setisLoading(false);
              });
          });
      })
      .catch(error => {
        this.setState({isLoading: false});
      });
  };
  // const getThemeData = React.useCallback(async () => {
  //   Singleton.getInstance()
  //     .getData(constants.CURRENT_THEME_MODE)
  //     .then(async res => {
  //       // setSelectedIndex(res);
  //       // console.log('CURRENT_THEME_MODE_int_Theme==', res);
  //       if (res != null) {
  //         if (res === '0') {
  //           setSelectedIndex(0);
  //           // Singleton.getInstance().statusChange.updateStatusBar();
  //           Actions.refresh();
  //         } else {
  //           setSelectedIndex(1);
  //           // Singleton.getInstance().statusChange.updateStatusBar();
  //           Actions.refresh();
  //         }
  //       } else {
  //         setSelectedIndex(0);
  //         // Singleton.getInstance().statusChange.updateStatusBar();
  //         Actions.refresh();
  //       }
  //     });
  // }, []);
  return (
    <Wrap style={{backgroundColor: ThemeManager.colors.backgroundColor}}>
      <MainStatusBar
        backgroundColor={ThemeManager.colors.backgroundColor}
        barStyle={
          ThemeManager.colors.themeColor === 'light'
            ? 'dark-content'
            : 'light-content'
        }
      />
      {
        <CoustomModal
          modalVisible={modalVisible}
          setModalVisible={setModalVisible}></CoustomModal>
      }
      {/* <LinearGradient
        colors={['#000000', '#000000', '#1D1D1B', '#1D1D1B']}
        style={{flex: 1}}
        start={{x: 0, y: 0}}
        end={{x: 1, y: 0}}> */}
      {/* <MainHeader
          onpress2={() =>
            coinData.length > 0 &&
            Actions.currentScene != 'SelectBlockchain' &&
            Actions.SelectBlockchain({blockChainsList: coinData})
          }
          onpress3={() =>
           // Actions.currentScene != 'GetSupport' && Actions.GetSupport()
           setModalVisible(true)
          }
          styleImg3={{tintColor: '#B1B1B1'}}
          firstImg={images.Bell}
          secondImg={images.scan}
          thridImg={images.hamburger}
        /> */}

      <MainHeader
        goback={false}
        // onpress2={() =>
        //   Actions.currentScene != 'SelectBlockchain' &&
        //   Actions.SelectBlockchain({ blockChainsList: walletList })
        // }
        searchEnable={true}
        onChangedText={text => {
          //  alert(text)
          Search = text;
          setTimeout;
        }}
        // from={'search'}
        onpress3={() =>
          //    setModalVisible(true)
          // Actions.currentScene != 'Setting' && Actions.Setting()
          Actions.currentScene != 'Setting' &&
          props.navigation.navigate('Setting', {
            onGoBack: () => {
              // getThemeData();
            },
          })
        }
        onpress2={() => {
          Actions.currentScene != 'Notification' && Actions.Notification();
        }}
        styleImg3={{tintColor: '#B1B1B1', width: 20}}
        //  firstImg={Images.Bell}
        secondImg={ThemeManager.ImageIcons.bellIcon}
        thridImg={ThemeManager.ImageIcons.setting}
      />

      {/* <View
        style={{
          backgroundColor: '#1D212B',
          width: '100%',
          height: 1,
          marginVertical: 8,
          opacity: 0.5,
        }}></View> */}

      <View style={styles.roundView}>
        <View
          style={{
            flexDirection: 'row',
            justifyContent: 'space-between',
            borderColor: '#1D212B',
            opacity: 0.5,
            borderWidth: 1,
            paddingHorizontal: 8,
          }}>
          {tabData.map((item, index) => (
            <TouchableOpacity
              style={{
                padding: 10,
                alignItems: 'center',
                justifyContent: 'center',
              }}
              onPress={() => {
                selectedInd = index;
                setSelectedIndex(index);
                setTabSatus(item.title);
                // console.log("checkTabStatus",tabstatus);
              }}>
              {/* <Text
                style={{
                  color:
                    selectedInd == index
                      ? ThemeManager.colors.textColor
                      : Colors.fadetext,
                  fontSize: 13,
                  fontFamily: selectedInd == index ? Fonts.bold : Fonts.regular,
                  textAlign: 'center',
                }}>
                {item.title}
              </Text> */}
              {/* <TradeHeader
                custmTabTxt={{
                  fontSize: 13,
                  fontFamily:
                    selectedIndex == index ? Fonts.bold : Fonts.regular,
                }}
                title={item.title}
                underLine={selectedIndex == index ? true : false}
              /> */}
            </TouchableOpacity>
          ))}
        </View>

        {openSearch == false ? (
          <View></View>
        ) : (
          // <TouchableOpacity
          //   onPress={() => onSearchBarClick(true)}
          //   style={styles.searchView}>
          //   {/* <View style={styles.rowView}>
          //     <Text style={{fontSize: 12, color: '#808080'}}>
          //       {LanguageManager.searchToken}
          //     </Text>
          //     <Image source={images.Search} style={styles.searchImg} />
          //   </View> */}
          // </TouchableOpacity>
          <View style={{}}>
            {/* <SearchBar
                text={Search}
                width="100%"
                onChangeText={text => {
                  Search = text;
                  setsearchSet(!searchSet);
                }}
                onSubmitEditing={() => getCoinList()}
                placeholder="Search "
                returnKeyType={'done'}
                onPressImg={() => {
                  Search = '';
                  getCoinList();
                }}
                imgstyle={styles.imgstyle}
                icon={Search.length > 0 ? images.cancel : images.searchIcon}
                iconStyle={
                  Search.length > 0 ? styles.searchIcon1 : styles.searchIcon
                }></SearchBar> */}
          </View>
        )}
        {/* <FlatList
          contentContainerStyle={{
            marginTop: 15,
            paddingBottom: 70,
            flexGrow: 1,
          }}
          data={coinData}
          keyExtractor={(item, index) => index + ''}
          onScroll={({nativeEvent}) => {
            isCloseToBottom(nativeEvent);
          }}
          ListEmptyComponent={
            <View style={styles.NoDataStyle}>
              <Text style={styles.NoDataTextStyle}>No Data found</Text>
            </View>
          }
          renderItem={({item, index}) => (
            <TouchableOpacity
              onPress={() => coinSelection(item)}
              style={styles.coinsListStyle}>
              <View style={{flexDirection: 'row', width: '44%'}}>
                {item.coin_image ? (
                  <Image
                    source={{
                      uri: item.coin_image.includes('https')
                        ? item.coin_image
                        : BASE_IMAGE + item.coin_image,
                    }}
                    style={styles.coinStyle}
                  />
                ) : (
                  <View style={[styles.nameImage_style]}>
                    <Text style={styles.tokenImageText_style}>
                      {item.coin_name.charAt(0).toUpperCase()}
                    </Text>
                  </View>
                )}
                <View style={{marginLeft: 10}}>
                  <Text style={{color: Colors.fadetext}}>
                    {item.coin_name.toString().length > 13
                      ? item.coin_name.substring(0, 13) + '...'
                      : item.coin_name}
                  </Text>
                  <View style={{flexDirection: 'row'}}>
                    <Text style={{color: Colors.pink}}>
                      {Singleton.getInstance().CurrencySymbol}
                      {Singleton.getInstance().exponentialToDecimal(
                        Singleton.getInstance().toFixed(
                          item.perPrice_in_fiat,
                          4,
                        ),
                      )}
                    </Text>
                  </View>
                </View>
              </View>
              <View
                style={{
                  width: '25%',
                  marginRight: 10,
                  alignSelf: 'flex-start',
                }}>
                <AreaChart
                  style={{height: 50}}
                  data={item.graphData}
                  contentInset={{top: 20, bottom: 20}}
                  curve={shape.curveNatural}
                  svg={{
                    strokeWidth: 0.01,
                    fill: item.price_change_percentage < 0 ? 'red' : 'green',
                    fillOpacity: 0.05,
                  }}>
                  {item.price_change_percentage > 0 ? <Line /> : <Line1 />}
                </AreaChart>
              </View>
              <View style={styles.balanceViewStyle}>
                <Text style={styles.balanceText}>
                  {item.balance != 0
                    ? Singleton.getInstance().exponentialToDecimal(
                        Singleton.getInstance().toFixed(
                          Singleton.getInstance().exponentialToDecimal(
                            item.balance,
                          ),
                          Constants.CRYPTO_DECIMALS,
                        ),
                      )
                    : item.balance}{' '}
                  {item.coin_symbol.toUpperCase()}
                </Text>
                <Text style={styles.coinPriceStyle}>
                  {Singleton.getInstance().CurrencySymbol}
                  {Singleton.getInstance().toFixed(
                    item.perPrice_in_fiat * item.balance,
                    2,
                  )}
                </Text>
              </View>
            </TouchableOpacity>
          )}
        /> */}

        {tabstatus == 'Hot' ? (
          <Hot hotData={HotData} />
        ) : tabstatus == 'Gainer' ? (
          <Gainer gainerData={GainerData} />
        ) : tabstatus == 'Loser' ? (
          <Loser loserData={LoserData} />
        ) : (
          <HourChanges hourlyData={HourlyData} />
        )}
      </View>
      {/* </LinearGradient> */}

      {isLoading && <Loader />}
    </Wrap>
  );
};
// Market.navigationOptions = ({navigation}) => {
//   return {
//     header: null,
//     tabBarLabel: ' ',
//     tabBarIcon: ({focused}) => (
//       <TabIcon
//         focused={focused}
//         title={LanguageManager.Market}
//         ImgSize={{width: 19, height: 19}}
//         activeImg={ThemeManager.ImageIcons.marketActive}
//         defaultImg={Images.market_inactive}
//       />
//     ),
//     tabBarOptions: {
//       style: {
//         backgroundColor: ThemeManager.colors.backgroundColor,
//         // bottom: 5,
//       },
//     },
//   };
// };
export default Market;

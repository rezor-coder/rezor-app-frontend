/* eslint-disable react/self-closing-comp */
/* eslint-disable react-native/no-inline-styles */
import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  ImageBackground,
  Image,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Alert,
  Linking,
} from 'react-native';
import {Wrap} from '../../common/Wrap';
import {BasicButton, MainHeader, SimpleHeader, SubHeader} from '../../common';
import {Actions} from 'react-native-router-flux';
import images from '../../../theme/Images';
import styles from './SaitaProSupportStyle';
import {
  logoutUser,
  enableDisableNoti,
  getEnableDisableNotiStatus,
  getSocialList,
  changeThemeAction,
} from '../../../Redux/Actions';
import {Colors, Images} from '../../../theme';
import {SettingBar} from '../../common/SettingBar';
import fonts from '../../../theme/Fonts';
import * as constants from './../../../Constant';
import {ActionConst} from 'react-native-router-flux';
import Singleton from '../../../Singleton';
import {connect, useDispatch, useSelector} from 'react-redux';
import Loader from '../Loader/Loader';
import {DAPP_IMG_URL} from '../../../Endpoints';
import {LanguageManager, ThemeManager} from '../../../../ThemeManager';
import {CoustomModal} from '../../common/CoustomModal';
import {EventRegister} from 'react-native-event-listeners';
import LinearGradient from 'react-native-linear-gradient';

let showLoader = true;
const SaitaProSupport = props => {
  const dispatch = useDispatch();
  const [enable, setEnable] = useState(true);
  const [linkList, setlinkList] = useState('');
  const [isLoading, setisLoading] = useState(false);
  const [onPressActive, setPressActive] = useState(false);
  const walletList = useSelector(state => state?.walletReducer?.myWallets);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(null);
  useEffect(() => {
    props.navigation.addListener('didFocus', () => {
      // getThemeData();
      Singleton.getInstance()
        .getData('socialLinks')
        .then(socialLinks => {
          console.log('socialLinks', socialLinks);
          if (socialLinks) {
            showLoader = false;
            setlinkList(JSON.parse(socialLinks));
          }
        });

      EventRegister.addEventListener('downModal', data1 => {
        setModalVisible(false);
      });
    });
    // socialLinkList();
  }, []);

  return (
    <Wrap style={{backgroundColor: ThemeManager.colors.backgroundColor}}>
      <View style={[styles.centeredView, props.ModalStyle]}>
        <SimpleHeader
          title={LanguageManager.saitaProSupport}
          backImage={ThemeManager.ImageIcons.iconBack}
          titleStyle
          imageShow
          back={false}
          backPressed={() => Actions.pop()}
        />

        <View
          style={{
            height: 2,
            width: '100%',
            backgroundColor: ThemeManager.colors.chooseBorder,
            marginTop: 10,
            opacity: 0.6,
          }}
        />

        <View
          style={{
            flexDirection: 'row',
            paddingHorizontal: 25,
            justifyContent: 'space-between',
            marginTop: 60,
          }}>
          <TouchableOpacity
            disabled
            style={{
              height: 60,
              width: '45%',
              borderColor: Colors.borderColorLang,
              borderWidth: 1,
              borderRadius: 12,
              marginEnd: 20,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Image
              source={Images.saita}
              style={{height: 20, width: 20, marginHorizontal: 5}}
            />
            <Text
              style={[
                styles.textnewlight,
                {color: ThemeManager.colors.textColor},
              ]}>
              SaitaPro
            </Text>
          </TouchableOpacity>
          <BasicButton
            onPress={() => {
              Linking.openURL('https://fang.art');
            }}
            btnStyle={{
              // flex: 1,
              // marginHorizontal: 10,
              height: 55,
              justifyContent: 'center',
              borderRadius: 10,
              // paddingHorizontal: 25,
              width: '45%',
            }}
            customGradient={{borderRadius: 10, height: 55, width: '100%'}}
            // colors={Singleton.getInstance().dynamicColor}
            text={'FANG Art'}
            rightImage
            icon={Images.imgFangArt}
            textStyle={{fontSize: 14, fontFamily: fonts.regular}}
          />
          {/* <TouchableOpacity
            onPress={() => {
              Linking.openURL('https://fang.art');
            }}
            style={{
              height: 60,
              width: 160,
              borderColor: Colors.borderColorLang,
              borderWidth: 1,
              borderRadius: 12,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <LinearGradient
              // colors={[
              //   Colors.buttonColor1,
              //   Colors.buttonColor2,
              //   Colors.buttonColor3,
              //   Colors.buttonColor4,
              // ]}
              colors={
                Singleton.getInstance().dynamicColor
                  ? Singleton.getInstance().dynamicColor
                  : [
                      Colors.buttonColor1,
                      Colors.buttonColor2,
                      Colors.buttonColor3,
                      Colors.buttonColor4,
                    ]
              }
              style={styles.gradientStyle}
              start={{x: 0, y: 1}}
              end={{x: 0, y: 0}}>
              <Image
                source={Images.imgFangArt}
                style={{height: 20, width: 20, marginHorizontal: 5}}
              />
              <Text style={styles.textnewlight}>FANG Art</Text>
            </LinearGradient>
          </TouchableOpacity> */}
        </View>

        <View
          style={{
            flexDirection: 'row',
            paddingHorizontal: 25,
            justifyContent: 'space-between',
            marginTop: 20,
          }}>
          <TouchableOpacity
            disabled
            style={{
              height: 60,
              width: '45%',
              borderColor: Colors.borderColorLang,
              borderWidth: 1,
              borderRadius: 12,
              marginEnd: 20,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Image
              source={Images.imgSubTract}
              style={{height: 20, width: 20, marginHorizontal: 5}}
            />
            <Text
              style={[
                styles.textnewlight,
                {color: ThemeManager.colors.textColor},
              ]}>
              Saitama Store
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            disabled
            style={{
              height: 60,
              width: '45%',
              borderColor: Colors.borderColorLang,
              borderWidth: 1,
              borderRadius: 12,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Image
              source={Images.imgSaitaMarket}
              style={{height: 20, width: 20, marginHorizontal: 5}}
            />
            <Text
              style={[
                styles.textnewlight,
                {color: ThemeManager.colors.textColor},
              ]}>
              SaitaMarket
            </Text>
          </TouchableOpacity>
        </View>

        <View
          style={{
            flexDirection: 'row',
            paddingHorizontal: 25,
            justifyContent: 'space-between',
            marginTop: 20,
          }}>
          <TouchableOpacity
            onPress={() => {
              Linking.openURL('https://saitama.academy');
            }}
            style={{
              height: 60,
              width: '45%',
              borderColor: Colors.borderColorLang,
              borderWidth: 1,
              borderRadius: 12,
              marginEnd: 20,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Image
              source={Images.imgLearn}
              style={{height: 20, width: 20, marginHorizontal: 5}}
            />
            <Text
              style={[
                styles.textnewlight,
                {color: ThemeManager.colors.textColor},
              ]}>
              Learn
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => {
              Actions.currentScene != 'GetSupport' && Actions.GetSupport();
            }}
            style={{
              height: 60,
              width: '45%',
              borderColor: Colors.borderColorLang,
              borderWidth: 1,
              borderRadius: 12,
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
            <Image
              source={Images.imgSaitaMarket}
              style={{height: 20, width: 20, marginHorizontal: 5}}
            />
            <Text
              style={[
                styles.textnewlight,
                {color: ThemeManager.colors.textColor},
              ]}>
              Get Support
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </Wrap>
  );
};

const mapStateToProp = state => {
  const {} = state.walletReducer;
  return {};
};

// export default connect(mapStateToProp, {
//   getSocialList,
//   logoutUser,
//   enableDisableNoti,
//   getEnableDisableNotiStatus,
// })(SaitaProSupport);
export default SaitaProSupport;

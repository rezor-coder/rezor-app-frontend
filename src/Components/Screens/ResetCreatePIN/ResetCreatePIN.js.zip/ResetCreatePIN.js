import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  KeyboardAvoidingView,
} from 'react-native';
import {Actions} from 'react-native-router-flux';
import colors from '../../../theme/Colors';
import images from '../../../theme/Images';
import {BasicButton, BorderLine, SubHeader} from '../../common';
import SmoothPinCodeInput from 'react-native-smooth-pincode-input';
import {Wrap} from '../../common/Wrap';
import {ButtonPrimary} from '../../common/ButtonPrimary';
import {styles} from './ResetCreatePINStyle';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';
import Singleton from '../../../Singleton';
import * as constants from '../../../Constant';
import {SimpleHeader} from '../../common';
import {LanguageManager, ThemeManager} from '../../../../ThemeManager';
const ResetCreatePIN = props => {
  const [pin, setPin] = useState('');
  const [confirmPin, setconfirmPin] = useState('');
  const onProceed = () => {
    if (pin.length == 0 || pin.length < 6) {
      Singleton.showAlert(constants.ENTERPIN);
      return;
    }
    if (confirmPin.length == 0 || confirmPin.length < 6) {
      Singleton.showAlert(constants.CONFIRMPIN);
      return;
    }
    if (pin != confirmPin) {
      Singleton.showAlert(constants.CHECKPIN);
      return;
    } else {
      Singleton.getInstance().saveData(constants.PIN, pin);
      // Singleton.getInstance().saveData(constants.ENABLE_PIN, 'true');
      Singleton.showAlert(constants.UPDATEDPIN);
      Actions.currentScene != 'Dashboard' && Actions.Dashboard();
    }
  };
  return (
    <Wrap style={{backgroundColor: ThemeManager.colors.backgroundColor}}>
      {/* <SimpleHeader title={LanguageManager.ResetCreatePIN} /> */}
      <SimpleHeader
        title={LanguageManager.ResetCreatePIN}
        // rightImage={[styles.rightImgStyle]}
        backImage={ThemeManager.ImageIcons.iconBack}
        titleStyle
        imageShow
        back={false}
        backPressed={() => {
          // props.navigation.state.params.onGoBack();
          props.navigation.goBack();
        }}
      />
      <BorderLine
        borderColor={{backgroundColor: ThemeManager.colors.chooseBorder}}
      />
      <View style={styles.mainView}>
        <View style={styles.textInputView}>
          <View style={styles.textInput}>
            <Text
              style={[styles.pinText, {color: ThemeManager.colors.textColor}]}>
              {LanguageManager.enterNewPin}
            </Text>
          </View>
          <View style={styles.inputView}>
            <SmoothPinCodeInput
              autoFocus={true}
              password
              mask="﹡"
              cellSize={42}
              codeLength={6}
              cellStyleFocused={{borderColor: ThemeManager.colors.textColor}}
              cellStyle={[
                styles.cellStyle,
                {borderColor: ThemeManager.colors.inputBoxColor},
              ]}
              textStyle={[
                styles.inputText,
                {color: ThemeManager.colors.textColor},
              ]}
              value={pin}
              onTextChange={text => setPin(text)}
            />
            {/* <SmoothPinCodeInput
              autoFocus={true}
              password
              mask="﹡"
              cellSize={42}
              codeLength={6}
              cellStyleFocused={{
                borderColor: ThemeManager.colors.textColor,
              }}
              cellStyle={styles.cellStyle}
              textStyle={[
                styles.inputText,
                {color: ThemeManager.colors.textColor},
              ]}
              value={pin}
              onTextChange={text => {
                // this.setState({pin: text});
                // this.checkPin(text);
                // console.log('>>>>>', text, text.length);
              }}
            /> */}
          </View>
        </View>
        <View style={styles.confiemPinView}>
          <View style={styles.textInput}>
            <Text style={styles.pinText}>{LanguageManager.ConfirmPin}</Text>
          </View>
          <View style={styles.inputView}>
            <SmoothPinCodeInput
              password
              mask="﹡"
              cellSize={42}
              codeLength={6}
              cellStyleFocused={{borderColor: ThemeManager.colors.textColor}}
              cellStyle={[
                styles.cellStyle,
                {borderColor: ThemeManager.colors.inputBoxColor},
              ]}
              textStyle={[
                styles.inputText,
                {color: ThemeManager.colors.textColor},
              ]}
              value={confirmPin}
              onTextChange={text => setconfirmPin(text)}
            />
          </View>
        </View>
        {/* <ButtonPrimary
          btnstyle={styles.btnStyle}
          onpress={() => onProceed()}
          text="Proceed"
          btnStyle={styles.btnStyle}
          customGradient={styles.customGrad}
        /> */}
        <BasicButton
          onPress={() => {
            onProceed();
          }}
          // colors={btnColor}
          btnStyle={styles.btnStyle}
          customGradient={[styles.customGrad]}
          text={LanguageManager.proceed}
        />
        <View style={{paddingVertical: 20}}>
          <Text
            style={[
              styles.createPinTxt,
              {color: ThemeManager.colors.textColor},
            ]}>
            {LanguageManager.creatingAPin}
          </Text>
        </View>
        <View>
          <Text style={[styles.text, {color: ThemeManager.colors.textColor}]}>
            {LanguageManager.pinIsRequired}{' '}
          </Text>
          <Text style={[styles.text, {color: ThemeManager.colors.textColor}]}>
            {LanguageManager.toAccessTheWallet}
          </Text>
        </View>
        <TouchableOpacity
          onPress={() => Actions.pop()}
          style={[
            styles.btnView2,
            {borderColor: ThemeManager.colors.textColor},
          ]}>
          <Text style={{color: ThemeManager.colors.textColor}}>
            {LanguageManager.Back}
          </Text>
        </TouchableOpacity>
      </View>
    </Wrap>
  );
};
export default ResetCreatePIN;
